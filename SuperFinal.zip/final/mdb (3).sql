-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2019 at 10:53 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `id`) VALUES
('raj', '1234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comment_movie`
--

CREATE TABLE `comment_movie` (
  `Movie_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `user` varchar(100) COLLATE utf8_bin NOT NULL,
  `comment` varchar(500) COLLATE utf8_bin NOT NULL,
  `iid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `comment_movie`
--

INSERT INTO `comment_movie` (`Movie_Id`, `user`, `comment`, `iid`) VALUES
('MV003', 'khantil', 'Cooll!! Best Heroic Movie', 1),
('MV006', 'aqua', 'Total Fun!!!!!!                        ', 2),
('MV006', 'khantil', '  Best for Students!!!!                                                                      ', 3),
('MV004', 'khantil', 'Best Sports Related Movie!!!                                                                        ', 4),
('MV003', 'Raj', 'Ye Naya India Hay!!!!!!                                                                                                                ', 5),
('MV008', 'khantil', 'Beesssssst Movieeee Everrrr!!!!                                                                                                                                ', 6),
('MV008', 'khantil', '    Iron Man Is Just Out Of This World!!!!                                                                                                                            ', 7),
('MV008', 'khantil', 'Caps Entry Is just Mind Blowing.                                                                                                                                ', 8),
('MV008', 'khantil', '  cooooooooooooool                                                                                                                              ', 9),
('MV008', 'khantil', 'Nice Movie Though!!!!                                                                                                                                ', 10),
('125478', 'aqua', 'Brie Larson Is Just Mind Blowing In this Movie!                                                                                                                                ', 11);

-- --------------------------------------------------------

--
-- Table structure for table `comment_tvshows`
--

CREATE TABLE `comment_tvshows` (
  `TvShow_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `user` varchar(100) COLLATE utf8_bin NOT NULL,
  `comment` varchar(500) COLLATE utf8_bin NOT NULL,
  `iid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `comment_tvshows`
--

INSERT INTO `comment_tvshows` (`TvShow_Id`, `user`, `comment`, `iid`) VALUES
('TV002', 'aqua', 'All Time Favorite!!!!                        ', 1),
('TV005', 'khantil', 'All Time Best!!!                        ', 2),
('TV001', 'khantil', ' Cooooooool!!!Best Shows Ever!                                                   ', 3),
('TV001', 'Raj', 'Awwwwwwesome......                                                    ', 4),
('TV004', 'khantil', 'Best acting!!!!                                                    ', 5),
('TV009', 'khantil', 'Best Mind Games!!!!!!                                                    ', 6),
('TV002', 'lazerx', '  Science Is Much Of Fun!!!!                                                          ', 7),
('TV005', 'Core', 'Its My 10th Time Watching This Series!!                                                            ', 8);

-- --------------------------------------------------------

--
-- Table structure for table `commet_music`
--

CREATE TABLE `commet_music` (
  `Music_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `user` varchar(100) COLLATE utf8_bin NOT NULL,
  `comment` varchar(500) COLLATE utf8_bin NOT NULL,
  `iid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `commet_music`
--

INSERT INTO `commet_music` (`Music_Id`, `user`, `comment`, `iid`) VALUES
('MU004', 'khantil', ' Best Revenge Lyrics ever!!!!\r\n Go Taylor                       ', 1),
('MU001', 'khantil', 'DJ Snake Always Comes With Something Cool!!!!                                        ', 2),
('MU001', 'khantil', 'Future DJ SHAKIRA!!!!                                                ', 3),
('MU002', 'khantil', 'GO Alan!!!!!!                                                ', 4),
('MV008', 'khantil', 'Despacito quero faborito!!!!!                                                ', 5),
('MU11', 'khantil', 'Cooll!!!!!                                                ', 6),
('mv123', 'Core', ' We Never Getting Older!!!                                                   ', 7);

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `Movie_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Title` varchar(50) COLLATE utf8_bin NOT NULL,
  `Description` mediumtext COLLATE utf8_bin NOT NULL,
  `Top` int(10) NOT NULL,
  `Stars` int(5) NOT NULL,
  `Likes` bigint(200) NOT NULL,
  `Verdict` varchar(20) COLLATE utf8_bin NOT NULL,
  `Gross` float NOT NULL,
  `Reaction` varchar(20) COLLATE utf8_bin NOT NULL,
  `Poster` varchar(200) COLLATE utf8_bin NOT NULL,
  `Trailer` varchar(200) COLLATE utf8_bin NOT NULL,
  `Score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`Movie_Id`, `Title`, `Description`, `Top`, `Stars`, `Likes`, `Verdict`, `Gross`, `Reaction`, `Poster`, `Trailer`, `Score`) VALUES
('125478', 'Captain Marvel', 'Captain Marvel is an extraterrestrial Kree warrior who finds herself caught in the middle of an intergalactic battle between her people and the Skrulls.', 4, 4, 1, '', 456719000, 'a', 'https://lumiere-a.akamaihd.net/v1/images/p_captainmarvel_characterposter_captainmarvel_ddt-17547_f5799718.jpeg?region=0,0,300,450', '0LHxvxdRnYc', 0),
('MV002', 'Drishyam', 'A man goes to extreme lengths to save his family from punishment after the family commits an accidental crime.', 7, 4, 0, 'Block Blaster', 115264000, 'a', 'https://upload.wikimedia.org/wikipedia/en/thumb/8/8a/Drishyam_2015_film.jpg/220px-Drishyam_2015_film.jpg', 'AuuX2j14NBg', 0),
('MV003', 'URI : The Surgical Strike', 'Indian army special forces carry a cover operation , avenging the killing of fellow army men at their base by a terrorist group.', 5, 4, 1, 'Block Blaster', 336446000, 'a', 'https://upload.wikimedia.org/wikipedia/en/thumb/3/3b/URI_-_New_poster.jpg/220px-URI_-_New_poster.jpg', 'Cg8sbRFS3zU', 0),
('MV004', 'Dangal', 'Former wrestler Mahavir Singh Phogat and this two wrestler daughter struggle toward glory at the Commonwealth Games in the face  of societal oppression.', 1, 5, 0, 'World television pre', 21048700000, 'a', 'https://upload.wikimedia.org/wikipedia/en/thumb/9/99/Dangal_Poster.jpg/220px-Dangal_Poster.jpg', 'x_7YlGv9u1g', 0),
('MV005', 'Andhadhun', 'A series of mysterious events change the life of a blind pianist who now must report a crime that was actually never witnessed by him.  ', 6, 4, 0, 'Super Hit', 150249000, 'c', 'https://upload.wikimedia.org/wikipedia/en/thumb/4/4a/Andhadhun_Movie_Poster.jpg/220px-Andhadhun_Movie_Poster.jpg', '2iVYI99VGaw', 0),
('MV006', '3 Idiots', 'Two friends are searching for their long lost companion. They revisit their college days and recall the memories of their friend who inspired then to think differently,even as the rest the world called them \"idiots\".', 2, 5, 0, 'Super Hit', 4601250000, 'c', 'https://upload.wikimedia.org/wikipedia/en/thumb/d/df/3_idiots_poster.jpg/220px-3_idiots_poster.jpg', 'K0eDlFX9GMc', 0),
('MV008', 'Avengers Infinity War', 'The Avengers must stop Thanos and his army from acquiring all the infinity stones. But the mad Titan is prepared to go to any lengths in order to do what he thinks is necessary.', 3, 4, 5, 'World television pre', 2048360000, 'a', 'https://i.pinimg.com/originals/7b/5b/28/7b5b2873f784135a39e8c6f59e1f96b7.jpg', '6ZfuNTqbHE8', 0);

-- --------------------------------------------------------

--
-- Table structure for table `musics`
--

CREATE TABLE `musics` (
  `Music_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Title` varchar(50) COLLATE utf8_bin NOT NULL,
  `Score` float NOT NULL,
  `Top` int(10) NOT NULL,
  `Poster` varchar(200) COLLATE utf8_bin NOT NULL,
  `Song` varchar(200) COLLATE utf8_bin NOT NULL,
  `Totel_Stream` bigint(50) NOT NULL,
  `Likes` bigint(50) NOT NULL,
  `Youtub_Views` bigint(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `musics`
--

INSERT INTO `musics` (`Music_Id`, `Title`, `Score`, `Top`, `Poster`, `Song`, `Totel_Stream`, `Likes`, `Youtub_Views`) VALUES
('MU001', 'Taki Taki', 8.5, 5, 'https://upload.wikimedia.org/wikipedia/en/thumb/8/8b/Taki_Taki_%28Official_Single_Cover%29_-_DJ_Snake.png/220px-Taki_Taki_%28Official_Single_Cover%29_-_DJ_Snake.png', 'ixkoVwKQaJg', 789516245, 10652438, 1253898718),
('MU002', 'On my Way', 9.3, 8, 'https://upload.wikimedia.org/wikipedia/en/thumb/a/af/Alan_Walker_-_On_My_Way.png/220px-Alan_Walker_-_On_My_Way.png', 'dhYOPzcsbGM', 456217795, 2729359, 62343921),
('MU003', '7 Rings', 8.6, 7, 'https://upload.wikimedia.org/wikipedia/en/thumb/b/b7/Ariana_Grande_-_7_rings.png/220px-Ariana_Grande_-_7_rings.png', 'QYh6mYIJG2Y', 374523648, 6719736, 322677708),
('MU004', 'Look What You Made Me Do', 8.7, 6, 'https://upload.wikimedia.org/wikipedia/en/thumb/6/68/Taylor_Swift_-_Look_What_You_Made_Me_Do.png/220px-Taylor_Swift_-_Look_What_You_Made_Me_Do.png', '3tmd-ClpJxA', 742536894, 8413581, 1036052714),
('MU005', 'Mi Gente', 8.6, 2, 'https://upload.wikimedia.org/wikipedia/en/thumb/9/99/J_Balvin_Mi_Gente.jpg/220px-J_Balvin_Mi_Gente.jpg', 'wnJ6LuUFpMo', 457896321, 11919374, 2312172716),
('MU008', 'Despacito', 0, 1, 'https://m.media-amazon.com/images/I/81yI97U4nnL._SS500_.jpg', 'kJQP7kiw5Fk', 896541236, 32772733, 6120335850),
('MU11', 'Blank Space', 0, 3, 'https://i.pinimg.com/236x/98/6a/b8/986ab8a3a288cc9cc8f234f58bb67288--heart-songs-latest-updates.jpg', 'e-ORhEE9VVg', 123654789, 8910136, 2430648449),
('mv123', 'Closer', 0, 4, 'https://i1.sndcdn.com/artworks-000173935001-g1x896-t500x500.jpg', 'PT2_F-1esPk', 123654789, 9197144, 2281045904);

-- --------------------------------------------------------

--
-- Table structure for table `music_person`
--

CREATE TABLE `music_person` (
  `Music_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Person_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Role_Id` varchar(10) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `music_person`
--

INSERT INTO `music_person` (`Music_Id`, `Person_Id`, `Role_Id`) VALUES
('MU11', '123654', ''),
('MU008', '965', 'aa'),
('MU005', 'PR020', 'RL005'),
('MU005', 'PR021', 'RL005'),
('MU002', 'PR022', 'RL005'),
('MU003', 'PR023', 'RL005'),
('MU004', 'PR024', 'RL005'),
('MU001', 'PR025', 'RL005'),
('MU005', 'PR026', 'RL005'),
('mv123', 'ZyNba', 'aaa');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `Person_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Name` varchar(35) COLLATE utf8_bin NOT NULL,
  `Gender` varchar(6) COLLATE utf8_bin NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`Person_Id`, `Name`, `Gender`, `DOB`) VALUES
('123654', 'Taylor Swift', 'Female', '2019-04-10'),
('965', 'Luis Fonsi', 'Male', '2019-04-10'),
('PR001', 'Ajit Andhare', 'Male', '1973-07-11'),
('PR002', 'Nishikant Kamat', 'Male', '1969-01-27'),
('PR003', 'Ajay Devgan', 'Male', '1969-04-02'),
('PR004', 'Tabu', 'Female', '1971-11-04'),
('PR005', 'Aditya Dhar', 'Male', '1983-03-12'),
('PR006', 'Ronnie Screwvala', 'Male', '1962-10-08'),
('PR007', 'Vicky  kaushal', 'Male', '1988-05-16'),
('PR008', 'Yami Gautam', 'Female', '1988-11-28'),
('PR009', 'Nitesh Tiwari', 'Male', '0000-00-00'),
('PR010', 'Amir Khan', 'Male', '1965-03-14'),
('PR011', 'Fatima sana Shaikh', 'Female', '1992-01-11'),
('PR012', 'Sriram Raghavan', 'Male', '1963-06-22'),
('PR013', 'Keval Garg', 'Male', '0000-00-00'),
('PR014', 'Ayushmann Khurana', 'Male', '1984-10-14'),
('PR015', 'Rajkumar Hirani', 'Male', '1962-11-20'),
('PR016', 'Vidhu Vinod Chopra', 'Male', '1952-10-05'),
('PR017', 'R. Madhavan', 'Male', '1970-06-01'),
('PR018', 'Sharman Joshi', 'Male', '1979-04-28'),
('PR019', 'Kareena  kapur', 'Female', '1980-10-21'),
('PR020', 'J Balvin', 'Male', '1958-05-07'),
('PR021', 'Willy William', 'Male', '1981-04-14'),
('PR022', 'Alan Walker', 'Male', '1997-08-24'),
('PR023', 'Ariana Grande', 'Female', '1993-06-26'),
('PR024', 'Taylor Swift', 'Female', '1989-12-13'),
('PR025', 'Dj Snake', 'Male', '1989-06-13'),
('PR026', 'Selena Gomez', 'Female', '1992-06-22'),
('ZyNba', 'Chainsmokers', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `rid` int(11) NOT NULL,
  `user` varchar(200) NOT NULL,
  `media` varchar(20) NOT NULL,
  `mediaid` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`rid`, `user`, `media`, `mediaid`) VALUES
(4, 'khantil', 'music', 'MU004'),
(5, 'aqua', 'tv', 'TV002'),
(6, 'aqua', 'movie', 'MV006'),
(10, 'khantil', 'movie', 'MV006'),
(11, 'khantil', 'movie', 'MV006'),
(12, 'khantil', 'music', 'MU001'),
(13, 'khantil', 'movie', 'MV004'),
(14, 'khantil', 'music', 'MU001'),
(15, 'Raj', 'movie', 'MV003'),
(16, 'khantil', 'tv', 'TV001'),
(17, 'Raj', 'tv', 'TV001'),
(18, 'khantil', 'music', 'MU002'),
(19, 'khantil', 'tv', 'TV004'),
(20, 'khantil', 'tv', 'TV009'),
(21, 'khantil', 'music', 'MV008'),
(22, 'khantil', 'music', 'MU11'),
(23, 'khantil', 'movie', 'MV008'),
(24, 'khantil', 'movie', 'MV008'),
(25, 'khantil', 'movie', 'MV008'),
(26, 'khantil', 'movie', 'MV008'),
(27, 'khantil', 'movie', 'MV008'),
(28, 'khantil', 'movie', 'MV008'),
(29, 'lazerx', 'tv', 'TV002'),
(30, 'aqua', 'movie', '125478'),
(31, 'Core', 'music', 'mv123'),
(32, 'Core', 'tv', 'TV005');

-- --------------------------------------------------------

--
-- Table structure for table `tvshows`
--

CREATE TABLE `tvshows` (
  `TvShow_Id` varchar(10) COLLATE utf8_bin NOT NULL,
  `Title` varchar(50) COLLATE utf8_bin NOT NULL,
  `Current_Season` int(10) NOT NULL,
  `Description` varchar(1000) COLLATE utf8_bin NOT NULL,
  `Poster` varchar(200) COLLATE utf8_bin NOT NULL,
  `Trailer` varchar(200) COLLATE utf8_bin NOT NULL,
  `Stars` int(5) NOT NULL,
  `Top` int(10) NOT NULL,
  `TRP` float NOT NULL,
  `Likes` int(11) NOT NULL,
  `Score` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tvshows`
--

INSERT INTO `tvshows` (`TvShow_Id`, `Title`, `Current_Season`, `Description`, `Poster`, `Trailer`, `Stars`, `Top`, `TRP`, `Likes`, `Score`) VALUES
('TV001', 'Game of Thrones', 7, 'Nine noble families fight for control over the mythical lands of Westeros, while an ancient enemy returns after being dormant for thousands of years.', 'http://www.gstatic.com/tv/thumb/tvbanners/16473346/p16473346_b_v8_ab.jpg', 'rlR4PJn8b8I', 4, 3, 9558, 2, 0),
('TV002', 'The Big Bang Theory', 12, 'A woman who moves into an apartment acrooss the hall form two brilliant but socially awkward physicists shows them how little they know about life outside of the laboratory', 'https://images-na.ssl-images-amazon.com/images/I/51gWaYQxbML.jpg', 'WBb3fojgW0Q', 4, 4, 9021, 1, 0),
('TV003', 'Mirzapur', 1, 'A shocking incident at a wedding procession ignites a series of events entangling the lives of two families in the lawless city of mirzapur. ', 'http://www.gstatic.com/tv/thumb/tvbanners/16201106/p16201106_b_v8_aa.jpg', 'ZNeGF-PvRHY', 3, 5, 8566, 0, 0),
('TV004', 'Sacred Games', 1, 'A link in their pasts leads an honest cop to a fugitive gang boss, whose cryptic warning spurs the officer on a quest to save Mumbai from cataclysm.', 'http://www.gstatic.com/tv/thumb/tvbanners/15540766/p15540766_b_v8_ae.jpg', '28j8h0RRov4', 2, 6, 7569, 1, 0),
('TV005', 'Friends', 10, 'Follow the lives of six reckless adults living in Manhattan, as they indulge in adventures which make their lives both troublesome and happening.', 'http://www.gstatic.com/tv/thumb/tvbanners/183931/p183931_b_v8_ac.jpg', 'Gpa5S8DgPzs', 5, 1, 9888, 1, 0),
('TV009', 'Sherlock Holmes', 4, 'In this contemporary version of Sir Arthur Conan Doyles detective stories, Dr. John Watson is a war vet just home from Afghanistan.', 'http://tvstock.net/sites/default/files/poster-sherlock-season-1.jpg', 'qlcWFoNqZHc', 5, 2, 9799, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_bin NOT NULL,
  `Email` varchar(320) COLLATE utf8_bin NOT NULL,
  `Password` varchar(16) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `username`, `Email`, `Password`) VALUES
(1, 'khantil', 'sam1@gmail.com', '1234'),
(8, 'addir', 'aoor@gmail.com', 'asdasdasdasd'),
(9, 'Raj', 'hrsrk9@outlook.com', '1234'),
(15, 'lazerx', 'asdas@332sdsd.com', '1452'),
(19, 'aqua', 'man@dc.com', '123'),
(20, 'Core', 'asfg@outlook.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment_movie`
--
ALTER TABLE `comment_movie`
  ADD PRIMARY KEY (`iid`);

--
-- Indexes for table `comment_tvshows`
--
ALTER TABLE `comment_tvshows`
  ADD PRIMARY KEY (`iid`);

--
-- Indexes for table `commet_music`
--
ALTER TABLE `commet_music`
  ADD PRIMARY KEY (`iid`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`Movie_Id`);

--
-- Indexes for table `musics`
--
ALTER TABLE `musics`
  ADD PRIMARY KEY (`Music_Id`);

--
-- Indexes for table `music_person`
--
ALTER TABLE `music_person`
  ADD PRIMARY KEY (`Person_Id`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`Person_Id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `tvshows`
--
ALTER TABLE `tvshows`
  ADD PRIMARY KEY (`TvShow_Id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comment_movie`
--
ALTER TABLE `comment_movie`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `comment_tvshows`
--
ALTER TABLE `comment_tvshows`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `commet_music`
--
ALTER TABLE `commet_music`
  MODIFY `iid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
